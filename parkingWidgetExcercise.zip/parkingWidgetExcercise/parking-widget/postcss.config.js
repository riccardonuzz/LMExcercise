module.exports = {
  plugins: {
    'postcss-import': {},
    'autoprefixer': {
      browsers: 'last 2 versions',
    },
    'cssnano': {},
  },
};