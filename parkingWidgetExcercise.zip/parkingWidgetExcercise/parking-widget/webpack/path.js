const prod_Path = '../dist';
const src_Path = 'src';

module.exports = {
  prod_Path,
  src_Path
}